# Add your import statements here
delimiters = '[.?!]'
punctuations = ['\'','\"','?', ':', '!', '.', ',', ';','&','#','(',')','[',']','{','}','_','|', '', ' ']
text_separators = "[' ,-/]"




# Add any utility functions here